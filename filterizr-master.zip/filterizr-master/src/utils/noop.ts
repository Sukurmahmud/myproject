/**
 * A no-operation function
 */
export const noop = (): void => {};
