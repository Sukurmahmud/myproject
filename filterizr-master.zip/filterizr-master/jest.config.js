/* global module */
module.exports = {
  roots: ['<rootDir>/tests', '<rootDir>/src'],
  transform: {
    '^.+\\.ts$': 'ts-jest',
  },
};
